package PlanesandFlights;

public interface IAvion {
	/// Getter
		public String getNom();
		public int getCapacitePassager();
		public int getPoids();
		public int getLargeur();
		public int getHauteur();
		public int getLongueur();
	 
	// Setter
		public void setNom(String pNom);
		public void setcapacitePassager(int pCapacitePassager);
		public void setPoids(int pPoids);
		public void setLargeur(int pLargeur);
		public void setHauteur(int pHauteur);
		public void setLongueur(int pLongueur);

	}


