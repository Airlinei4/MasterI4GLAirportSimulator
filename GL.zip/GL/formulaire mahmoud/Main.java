package Aeroport;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 
		Map<String, String> singleAddress = new HashMap<>();
;
		singleAddress.put("text1", "11");
		singleAddress.put("text2", "deux");
		singleAddress.put("iAvion", "iAvion");
		
		Formulaire form1 = new Formulaire (singleAddress);
		
	}

}
